﻿using System;

public class Example
{
    public static void Main()
    {
        var time = DateTime.Now;

        Console.WriteLine(time);
    }
}